package com.android.jungledjumble.Setting;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.android.jungledjumble.R;

public class ProgressActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_progress);
    }
}
